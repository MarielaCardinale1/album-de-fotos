import { useRef } from 'react';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { collection, addDoc } from 'firebase/firestore';
import { storage, db } from '../lib/firebase';
import EXIF from 'exif-js';

export default function PhotoUploader() {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    EXIF.getData(file as any, async function() {
      const lat = EXIF.getTag(this, "GPSLatitude");
      const lng = EXIF.getTag(this, "GPSLongitude");

      let gps = undefined;
      if (lat && lng) {
        gps = {
          lat: lat[0] + lat[1]/60 + lat[2]/3600,
          lng: lng[0] + lng[1]/60 + lng[2]/3600
        };
      }

      const storageRef = ref(storage, `uploads/${file.name}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      await addDoc(collection(db, 'files'), {
        name: file.name,
        storageUrl: url,
        gps: gps,
        folderId: 'current',
        year: new Date().getFullYear(),
        location: 'Unknown'
      });
    });
  };

  return (
    <>
      <button onClick={() => inputRef.current?.click()} className="bg-indigo-600 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-indigo-700 transition">
        Subir archivos
      </button>
      <input type="file" ref={inputRef} onChange={handleFileChange} className="hidden" />
    </>
  );
}
