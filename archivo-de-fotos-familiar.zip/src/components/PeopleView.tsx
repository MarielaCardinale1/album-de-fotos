import { Person } from '../types';
import { Camera } from 'lucide-react';

export default function PeopleView({ people }: { people: Person[] }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {people.map(person => (
        <div key={person.id} className="bg-slate-100 p-4 rounded-xl shadow-sm">
          <div className="aspect-square bg-slate-200 rounded-lg flex items-center justify-center mb-2">
            <Camera className="text-slate-400" size={32} />
          </div>
          <h4 className="font-semibold text-slate-900">{person.name}</h4>
          <p className="text-xs text-slate-500">{person.photoIds.length} fotos</p>
        </div>
      ))}
    </div>
  );
}
