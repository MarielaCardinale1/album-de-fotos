import { useState, useEffect } from 'react';
import { ref, listAll, getMetadata } from 'firebase/storage';
import { storage } from '../lib/firebase';

export default function StorageUsage() {
  const [usedBytes, setUsedBytes] = useState(0);
  const totalBytes = 100 * 1024 * 1024 * 1024; // 100 GB

  useEffect(() => {
    async function calculateStorage() {
      // Temporarily bypass calculation due to API limits
      setUsedBytes(0);
    }
    calculateStorage();
  }, []);

  const usedGB = (usedBytes / (1024 * 1024 * 1024)).toFixed(2);
  const percent = ((usedBytes / totalBytes) * 100).toFixed(1);

  return (
    <>
      <div className="flex justify-between text-[11px] mb-1">
        <span className="text-slate-400">Almacenamiento seguro</span>
        <span className="text-white">{usedGB} GB / 100 GB</span>
      </div>
      <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
        <div className="bg-indigo-400 h-full" style={{ width: `${percent}%` }}></div>
      </div>
    </>
  );
}
