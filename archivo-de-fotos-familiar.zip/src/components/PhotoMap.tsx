import { APIProvider, Map, AdvancedMarker } from '@vis.gl/react-google-maps';
import { File } from '../types';

export default function PhotoMap({ files }: { files: File[] }) {
  const photosWithGps = files.filter(f => f.gps);

  return (
    <div className="h-full w-full">
      <APIProvider apiKey={import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'DEMO_MAP_ID'}>
        <Map
          defaultCenter={{ lat: -34.6037, lng: -58.3816 }}
          defaultZoom={12}
          mapId="DEMO_MAP_ID"
        >
          {photosWithGps.map(file => (
            <AdvancedMarker
              key={file.id}
              position={file.gps!}
              title={file.name}
            />
          ))}
        </Map>
      </APIProvider>
    </div>
  );
}
