import { useState } from 'react';
import { Tag, Plus, X } from 'lucide-react';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { File } from '../types';

export default function TagManager({ file }: { file: File }) {
  const [newTag, setNewTag] = useState('');
  const tags = file.tags || [];

  const addTag = async () => {
    if (!newTag.trim()) return;
    const updatedTags = [...tags, newTag.trim()];
    await updateDoc(doc(db, 'files', file.id), { tags: updatedTags });
    setNewTag('');
  };

  const removeTag = async (tagToRemove: string) => {
    const updatedTags = tags.filter(t => t !== tagToRemove);
    await updateDoc(doc(db, 'files', file.id), { tags: updatedTags });
  };

  return (
    <div className="mt-4 p-4 border border-slate-200 rounded-lg">
      <h3 className="text-sm font-semibold mb-2 flex items-center gap-2"><Tag size={16} /> Etiquetas</h3>
      <div className="flex flex-wrap gap-2 mb-2">
        {tags.map(tag => (
          <span key={tag} className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded text-xs">
            {tag}
            <button onClick={() => removeTag(tag)}><X size={12} /></button>
          </span>
        ))}
      </div>
      <div className="flex gap-2">
        <input 
          type="text" 
          value={newTag} 
          onChange={(e) => setNewTag(e.target.value)}
          placeholder="Nueva etiqueta..."
          className="flex-1 text-xs px-2 py-1 border rounded"
        />
        <button onClick={addTag} className="bg-indigo-600 text-white p-1 rounded"><Plus size={14} /></button>
      </div>
    </div>
  );
}
