import { useState } from 'react';
import { Play } from 'lucide-react';

export default function StoryCreator({ folderId }: { folderId: string }) {
  const [year, setYear] = useState('2024');
  const [location, setLocation] = useState('');

  return (
    <div className="bg-slate-900 text-white p-6 rounded-xl">
      <h3 className="text-lg font-semibold mb-4">Generador de Historias</h3>
      <div className="space-y-4">
        <input type="text" placeholder="Año" value={year} onChange={e => setYear(e.target.value)} className="w-full bg-slate-800 border-none rounded-md p-2 text-sm" />
        <input type="text" placeholder="Ubicación" value={location} onChange={e => setLocation(e.target.value)} className="w-full bg-slate-800 border-none rounded-md p-2 text-sm" />
        <button className="w-full bg-indigo-600 text-white p-2 rounded-md text-sm font-semibold hover:bg-indigo-700">
          <Play size={16} className="inline mr-2" /> Crear Historia
        </button>
      </div>
    </div>
  );
}
