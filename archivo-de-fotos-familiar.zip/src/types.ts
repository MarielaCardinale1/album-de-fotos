export interface Folder {
  id: string;
  name: string;
  ownerId: string;
  members: string[];
}

export interface Person {
  id: string;
  name: string;
  faceEmbeddings: string[]; // Or reference to a representative photo
  photoIds: string[];
}

export interface File {
  id: string;
  folderId: string;
  name: string;
  storageUrl: string;
  year: number;
  location: string;
  gps?: {
    lat: number;
    lng: number;
  };
  personIds?: string[];
  tags?: string[];
}

export interface Comment {
  id: string;
  fileId: string;
  userId: string;
  text: string;
  timestamp: number;
}

export interface Suggestion {
  id: string;
  fileId: string;
  userId: string;
  changeType: 'edit' | 'delete' | 'move';
  status: 'pending' | 'approved' | 'rejected';
}

export interface Story {
  id: string;
  folderId: string;
  name: string;
  fileIds: string[];
  musicTrack: string;
  transitionType: 'fade' | 'slide' | 'zoom';
}
