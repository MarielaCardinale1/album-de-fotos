import { useState, useRef } from 'react';
import { Save, RotateCw, Crop, Filter, X } from 'lucide-react';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { doc, updateDoc } from 'firebase/firestore';
import { storage, db } from '../lib/firebase';
import { File } from '../types';
import TagManager from './TagManager';

export default function PhotoEditor({ file, onClose }: { file: File, onClose: () => void }) {
  const [rotation, setRotation] = useState(0);
  const [grayscale, setGrayscale] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleSave = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.toBlob(async (blob) => {
      if (!blob) return;
      const storageRef = ref(storage, `edited/${file.id}-${Date.now()}.jpg`);
      await uploadBytes(storageRef, blob);
      const newUrl = await getDownloadURL(storageRef);
      await updateDoc(doc(db, 'files', file.id), { storageUrl: newUrl });
      onClose();
    }, 'image/jpeg');
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-8">
      <div className="bg-white rounded-xl p-6 w-full max-w-2xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Editar: {file.name}</h2>
          <button onClick={onClose}><X size={24} /></button>
        </div>
        <div className="aspect-video bg-slate-100 mb-6 flex items-center justify-center overflow-hidden">
          <img src={file.storageUrl} alt={file.name} style={{ transform: `rotate(${rotation}deg)`, filter: `grayscale(${grayscale}%)` }} className="max-h-full" />
        </div>
        <div className="flex gap-4">
          <button onClick={() => setRotation(r => r + 90)} className="flex items-center gap-2 px-4 py-2 bg-slate-200 rounded-md"><RotateCw size={16} /> Rotar</button>
          <button onClick={() => setGrayscale(g => g === 0 ? 100 : 0)} className="flex items-center gap-2 px-4 py-2 bg-slate-200 rounded-md"><Filter size={16} /> {grayscale === 0 ? 'Blanco y Negro' : 'Color'}</button>
          <button onClick={handleSave} className="ml-auto flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md"><Save size={16} /> Guardar</button>
        </div>
        <TagManager file={file} />
        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
}
