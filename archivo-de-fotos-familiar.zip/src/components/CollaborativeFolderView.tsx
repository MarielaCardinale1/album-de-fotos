import { useState } from 'react';
import { MessageSquare, Check, X } from 'lucide-react';
import { File, Comment, Suggestion } from '../types';

export default function CollaborativeFolderView({ folderId }: { folderId: string }) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);

  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">Colaboración</h3>
      <div className="space-y-4">
        {/* Simplified display for now */}
        <div className="text-sm text-slate-500">
          <MessageSquare size={16} className="inline mr-2" />
          {comments.length} comentarios
        </div>
        <div className="text-sm text-slate-500">
          <Check size={16} className="inline mr-2" />
          {suggestions.filter(s => s.status === 'pending').length} sugerencias pendientes
        </div>
      </div>
    </div>
  );
}
