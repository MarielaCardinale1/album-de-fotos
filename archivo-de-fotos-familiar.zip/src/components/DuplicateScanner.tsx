import { useState, useEffect } from 'react';
import { ref, listAll, getMetadata, deleteObject } from 'firebase/storage';
import { storage } from '../lib/firebase';
import { Trash2, Search, AlertCircle } from 'lucide-react';

export default function DuplicateScanner() {
  const [duplicates, setDuplicates] = useState<Record<string, string[]>>({});
  const [loading, setLoading] = useState(false);

  const scanForDuplicates = async () => {
    setLoading(true);
    try {
      const rootRef = ref(storage, '/');
      const res = await listAll(rootRef);
      const hashGroups: Record<string, string[]> = {};

      for (const itemRef of res.items) {
        const metadata = await getMetadata(itemRef);
        const hash = metadata.md5Hash;
        if (hash) {
          if (!hashGroups[hash]) hashGroups[hash] = [];
          hashGroups[hash].push(itemRef.fullPath);
        }
      }

      const dups = Object.fromEntries(
        Object.entries(hashGroups).filter(([_, paths]) => paths.length > 1)
      );
      setDuplicates(dups);
    } catch (e) {
      console.error("Error scanning duplicates", e);
    } finally {
      setLoading(false);
    }
  };

  const deleteDuplicate = async (path: string) => {
    try {
      await deleteObject(ref(storage, path));
      await scanForDuplicates(); // Refresh
    } catch (e) {
      console.error("Error deleting file", e);
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Optimizador de Almacenamiento</h2>
        <button onClick={scanForDuplicates} disabled={loading} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md">
          <Search size={16} /> {loading ? 'Escaneando...' : 'Escanear Duplicados'}
        </button>
      </div>
      
      {Object.entries(duplicates).map(([hash, paths]) => (
        <div key={hash} className="bg-white p-4 rounded-lg shadow-sm mb-4 border border-slate-200">
          <p className="font-semibold text-sm mb-2 flex items-center gap-2 text-amber-600"><AlertCircle size={16} /> {paths.length} duplicados encontrados</p>
          <div className="space-y-2">
            {paths.map((path, index) => (
              <div key={path} className="flex justify-between items-center text-xs p-2 bg-slate-50 rounded">
                <span>{path}</span>
                {index > 0 && (
                  <button onClick={() => deleteDuplicate(path)} className="text-red-500 hover:text-red-700">
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
