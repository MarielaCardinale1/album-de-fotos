# Baúl de Memorias

Aplicación web para organizar y visualizar fotos y vídeos familiares.

## Requisitos

- Node.js
- npm

## Configuración

1. Crea tu propio proyecto Firebase y registra una aplicación web.
2. Completa `firebase-applet-config.json` con la configuración de tu proyecto.
3. Configura `GEMINI_API_KEY` en el entorno del servidor si vas a usar las funciones de IA. No publiques el valor de esa clave.
4. Configura las reglas de acceso de Firebase antes de cargar archivos.

## Iniciar localmente

```bash
npm install
npm run dev
```
