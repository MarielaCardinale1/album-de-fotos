/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Camera, LayoutGrid, Clock, MapPin, Lock, Search, Users, PlusCircle } from 'lucide-react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from './lib/firebase';
import CollaborativeFolderView from './components/CollaborativeFolderView';
import StoryCreator from './components/StoryCreator';
import PeopleView from './components/PeopleView';
import DuplicateScanner from './components/DuplicateScanner';
import StorageUsage from './components/StorageUsage';
import PhotoEditor from './components/PhotoEditor';
import PhotoUploader from './components/PhotoUploader';
import { File, Person } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'gallery' | 'albums' | 'shared' | 'people' | 'optimizer' | 'map'>('gallery');
  const [showStoryCreator, setShowStoryCreator] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
  const [files, setFiles] = useState<File[]>([]);
  const [editingFile, setEditingFile] = useState<File | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [people] = useState<Person[]>([]);

  const filteredFiles = files.filter(f => 
    f.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (f.tags && f.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase())))
  );

  const toggleFileSelection = (fileId: string) => {
    const newSelected = new Set(selectedFiles);
    if (newSelected.has(fileId)) {
      newSelected.delete(fileId);
    } else {
      newSelected.add(fileId);
    }
    setSelectedFiles(newSelected);
  };

  const downloadSelected = () => {
    files.filter(f => selectedFiles.has(f.id)).forEach(f => {
      const link = document.createElement('a');
      link.href = f.storageUrl;
      link.download = f.name;
      link.click();
    });
  };

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'files'), (snapshot) => {
      const filesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as File));
      setFiles(filesData);
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50 font-sans text-slate-900">
      <aside className="w-64 bg-slate-900 text-white flex flex-col shrink-0">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center overflow-hidden font-bold">
              <img src="image.png" alt="Logo" className="w-full h-full object-cover" />
            </div>
            <span className="text-xl font-semibold tracking-tight">Baúl de Memorias</span>
          </div>
          <nav className="space-y-1">
            <button onClick={() => setActiveTab('gallery')} className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'gallery' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}>
              <LayoutGrid size={16} /> Todas las fotos
            </button>
            <button onClick={() => setActiveTab('albums')} className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'albums' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}>
              <Clock size={16} /> Subidas recientes
            </button>
            <button onClick={() => setActiveTab('people')} className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'people' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}>
              <Users size={16} /> Personas
            </button>
            <button onClick={() => setActiveTab('optimizer')} className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'optimizer' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}>
              <Search size={16} /> Optimizador
            </button>
            <div className="pt-4 pb-2 px-3 text-[10px] uppercase tracking-wider text-slate-500 font-bold">Clasificación</div>
            <button className="w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-800 rounded-md text-sm">Años (1940-2024)</button>
            <button onClick={() => setActiveTab('map')} className={`w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-800 rounded-md text-sm ${activeTab === 'map' ? 'bg-slate-800' : ''}`}><MapPin size={16}/> Ubicaciones y Mapas</button>
            <div className="pt-4 pb-2 px-3 text-[10px] uppercase tracking-wider text-slate-500 font-bold">Familia y Compartir</div>
            <button onClick={() => setActiveTab('shared')} className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${activeTab === 'shared' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}><Users size={16}/> Círculo privado</button>
            <button className="w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-800 rounded-md text-sm italic">Álbum de la familia García</button>
          </nav>
        </div>
        <div className="mt-auto p-6 space-y-4 border-t border-slate-800">
          <div className="bg-slate-800 rounded-lg p-3">
            <StorageUsage />
          </div>
          <div className="flex items-center gap-2 text-[10px] text-emerald-400">
            <Lock size={12}/>
            <span>Cifrado de extremo a extremo</span>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 bg-white">
        <header className="h-16 border-b border-slate-200 flex items-center justify-between px-8">
          <div className="relative w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar por lugar, año, familiar o etiquetas..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-100 border-none rounded-full px-10 py-2 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => setShowStoryCreator(!showStoryCreator)} className="bg-slate-100 text-slate-700 px-4 py-2 rounded-md text-sm font-semibold hover:bg-slate-200 transition">
              <PlusCircle size={16} className="inline mr-2" /> Nueva Historia
            </button>
            <PhotoUploader />
            <div className="w-8 h-8 rounded-full bg-slate-200 border border-slate-300"></div>
          </div>
        </header>

        <div className="flex-1 p-8 overflow-y-auto">
          {showStoryCreator && <div className="mb-8"><StoryCreator folderId="current" /></div>}
          
          {activeTab === 'shared' ? (
            <CollaborativeFolderView folderId="current" />
          ) : activeTab === 'people' ? (
            <PeopleView people={people} />
          ) : activeTab === 'optimizer' ? (
            <DuplicateScanner />
          ) : activeTab === 'map' ? (
            <PhotoMap files={files} />
          ) : (
            <>
              <div className="flex items-baseline justify-between mb-6">
                <h2 className="text-2xl font-bold text-slate-900">Archivo Familiar Histórico <span className="text-slate-400 font-normal ml-2">(1994 - Buenos Aires)</span></h2>
                <div className="flex gap-2">
                  {selectedFiles.size > 0 && (
                    <>
                      <button onClick={downloadSelected} className="px-3 py-1 bg-indigo-600 text-white rounded text-xs font-semibold hover:bg-indigo-700">Descargar</button>
                      <button className="px-3 py-1 bg-emerald-600 text-white rounded text-xs font-semibold hover:bg-emerald-700">Compartir</button>
                    </>
                  )}
                  <span className="px-3 py-1 bg-slate-100 rounded text-xs font-semibold text-slate-600 border border-slate-200">Ordenar por: Fecha</span>
                  <span className="px-3 py-1 bg-slate-100 rounded text-xs font-semibold text-slate-600 border border-slate-200">Vista: Rejilla</span>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-6">
                {filteredFiles.map(file => (
                  <div key={file.id} className={`group relative aspect-square bg-slate-200 rounded-xl overflow-hidden shadow-sm cursor-pointer ${selectedFiles.has(file.id) ? 'ring-2 ring-indigo-500' : ''}`}>
                    <img src={file.storageUrl} alt={file.name} onClick={() => setEditingFile(file)} className="w-full h-full object-cover" />
                    <button onClick={() => toggleFileSelection(file.id)} className={`absolute top-2 left-2 w-6 h-6 rounded-full border-2 border-white flex items-center justify-center ${selectedFiles.has(file.id) ? 'bg-indigo-500' : 'bg-black/20'}`}>
                      {selectedFiles.has(file.id) && <div className="w-2 h-2 rounded-full bg-white"></div>}
                    </button>
                    <div className='absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/60 to-transparent text-white opacity-0 group-hover:opacity-100 transition-opacity'>
                      <p className='text-[10px] font-medium truncate'>{file.name}</p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
        
        {editingFile && <PhotoEditor file={editingFile} onClose={() => setEditingFile(null)} />}
        
        <footer className="h-14 bg-slate-50 border-t border-slate-200 flex items-center justify-between px-8 text-[11px] text-slate-500">
          <div className='flex gap-6'>
            <span className='flex items-center gap-2'><div className='w-1.5 h-1.5 bg-blue-500 rounded-full'></div> Sincronización activa: 14 dispositivos</span>
            <span className='flex items-center gap-2'><div className='w-1.5 h-1.5 bg-slate-300 rounded-full'></div> Última copia de seguridad: hace 2 mins</span>
          </div>
        </footer>
      </main>
    </div>
  );
}

