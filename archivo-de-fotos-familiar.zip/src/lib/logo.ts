import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from './lib/firebase';

export async function uploadLogo(file: File) {
  const storageRef = ref(storage, 'logo.png');
  await uploadBytes(storageRef, file);
  return await getDownloadURL(storageRef);
}
